#include <stdio.h>
#include <stdlib.h>

#include "joc.h"


int main(){
    #ifdef _WIN32
        system(""); // Activa ANSI en algunas versiones de Windows
    #endif
    // INICIALITZACI� DEL TAULER
    char tauler_actual[N][N];
    for(int i =0; i<N; i++)
        for(int j=0; j<N; j++)
            tauler_actual[i][j]='0';


    int jugador;
    int fila, columna;
    int empat = 1;
    int info=1;

    // TORNS DE TIRADES
    for (int i=0; i<N*N; i++){
        if (i%2 == 0){jugador = 1;}
        else{jugador = 2;}

        // Actualitzem la taula amb cada tirada
        tirada(tauler_actual, jugador, &fila, &columna, info);

        if (victoria(tauler_actual, jugador + '0', fila, columna)) {
            printf("El jugador %i ha guanyat!\n", jugador);
            empat=0;
            break;
        }
    }

    if (empat)
        printf("Empat!\n");

    printf("\n-TAULER  FINAL-\n");
    printTauler(tauler_actual);

    return 0;
}
