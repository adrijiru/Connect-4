#include <stdio.h>
#include <stdlib.h>
#define N 4

int calculaNumFills(char tauler[N][N]){
    int nfills=0;
    for(int i=0; i<N; i++){
        if(tauler[0][i]=='0')
            nfills++;
    }
    return nfills;
}

int main(){
    char tauler[N][N];
    for (int i=0; i<N; i++){
        for (int j=0; j<N; j++){
            tauler[i][j]='0';
        }
    }

    tauler[0][1]='X';

    int n_fills;
    n_fills=calculaNumFills(tauler);
    printf("fills: %i\n", n_fills);
    return 0;
}
