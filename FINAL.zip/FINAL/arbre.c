#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "joc.h"
#define PROF 9

typedef struct node {
	struct node * *fills;	//array de fills (pointers a node)
	int n_fills;
	char tauler[N][M];
	double valor;
} Node;

int calculaNumFills(char tauler[N][M]){
    int nfills = 0;
    for(int j=0; j<M; j++){
        if(tauler[0][j]=='0')
            nfills++;
    }
    return nfills;
}


int nfill_columna(char tauler[N][M], int numDeFill){    // AQUI
    int comptador = 0;
    for (int j=0; j<M; j++){
        if(detect(tauler, j, 0)){
            if (comptador==numDeFill){
                return j;
            }
        comptador++;
        }
    }
    return -1;
}

int tiradaAuto(char tauler[N][M], int numDeFill, char jugador, int *fila){
    //numDeFill diu quina posici� de les que hi ha lliures escull
    int columna = nfill_columna(tauler, numDeFill);
    *fila = gravity_sim(tauler, columna);

    tauler[*fila][columna] = jugador;

    return columna;
}

// heur�stica avalua nom�s els nodes fulla. Nom�s determina vict�ria i/o derrota (inicialment)
int heuristica(char tauler[N][M], int fila, int columna, char jugador){
    if (victoria(tauler, jugador, fila, columna)){
        if (jugador=='1'){return -100;}
        else{return 100;}
    }
    return 0;
}

Node* creaNode(Node *pare, int numDeFill, int nivell) {
	Node *p=malloc(sizeof(Node));
	memcpy(p->tauler, pare->tauler, sizeof(p->tauler));

    char jugador;
    if (nivell%2)
        jugador='2'; //BOT
    else
        jugador='1'; //J1

    int fila, columna;
    columna = tiradaAuto(p->tauler, numDeFill, jugador, &fila);

	if (nivell<PROF && !victoria(p->tauler, jugador, fila, columna)){ //Casos en els que pot tenir fills
		p->n_fills = calculaNumFills(p->tauler);
		p->fills = malloc(p->n_fills * sizeof(Node*));
	}
	else { //DECLAREM LES FULLES
		p->n_fills=0;
		p->fills=NULL;
        p->valor = heuristica(p->tauler, fila, columna, jugador);
	}
	return p;
}

void creaNivell(Node *pare, int nivell) {
    pare->valor = 0;
	for(int i=0; i < pare->n_fills; i++) {
		pare->fills[i] = creaNode(pare, i, nivell);

		//NOM�S HEM DE CREAR NIVELL SI ELS NODES NO SON FULLA!!!!!!!
		if (pare->fills[i]->n_fills>0){
            creaNivell(pare->fills[i], nivell+1); //CREEM D'ESQUERRA A DRETA DE L'ARBRE --- CANVIAR TRAIENT-LO DEL FOR!!!
		}
	}
}

//Aquesta funci� �s innecess�ria!!!!
void crearArbre(Node *arrel, int nivell) {
    creaNivell(arrel, nivell+1);  //crea 1 nivell a partir de l'arrel (pare)
    //Creem un nivell (n nodes) per cadascun dels fills
    //AQUEST CODI NOM�S ARRIBA A 2 NIVELLS DE PROFUNDITAT!!!!!!!!!
	/*for(int i=0 ; i < arrel->n_fills; i++) {
		creaNivell(arrel->fills[i], nivell+1);
	}*/
}

int tiradaPredeterminada(char tauler[N][M]){
//COLUMNA PREDETERMINADA
    printf("Bot escull la sortida predeterminada\n");
    int col = M/2;
    if (!detect(tauler, col, 0)){
        for (int j=1; j < M/2+1; j++){
            if (col+j<M && detect(tauler, col+j, 0)){return col+j;}
            else if (col-j>=0 && detect(tauler, col-j,0)){return col-j;}
        }
    printf("NO HI HA COLUMNES DISPONIBLES PER EL BOT.\n");
    return -1;
    }
    else{
        return col;
        }
}

int tiradaPredPrimersTorns(char tauler[N][M]){
    if(tauler[N-1][M/2]=='1'){tauler[N-2][M/2]='2';}
    else {tauler[N-1][M/2]='2';}
}


int MiniMax(Node *arrel, int nivell){ //fer-lo recursiu
    //MINMAX retorna la columna a la que ha de tirar el bot per a que la jugada sigui la m�s beneficiosa per ell
    if (arrel->fills == NULL){return -1;} //no t� fills!!!

    for (int i=0; i < arrel->n_fills; i++){
        //if (arrel->fills[i]->fills != NULL){ // quan apunta a fulles
            MiniMax(arrel->fills[i], nivell+1); //si no hem trobat el nivell, baixem un nivell
        //}
    }

    //un cop aqui ja sabem que apuntem a fulles, cal assignar el valor segons el nivell
    double punts = arrel->fills[0]->valor;
    if (nivell%2){//TIRA BOT, els fills son BOT, escollim el m�xim
        for (int i=1; i < arrel->n_fills; i++){
            if ((arrel->fills[i])->valor < punts){
                punts = (arrel->fills[i])->valor;
            }
        }
    }
    else{//JUGADOR, els fills son J1, escollim el m�nim
        for (int i=1; i < arrel->n_fills; i++){
            if ((arrel->fills[i])->valor > punts){
                punts = (arrel->fills[i])->valor;
            }
        }
    }

    arrel->valor = punts;
    //printf("PUNTS=%.0lf\n", punts);

    if (nivell == 0){
        //tirada predeterminada es dona sii tots els fills tenen la mateixa puntuaci�!
        int iguals=1;
        for (int i=1; i<arrel->n_fills; i++){
            if (arrel->fills[i]->valor != arrel->fills[0]->valor){
                iguals=0;
                break;
            }
        }
        if (iguals){
            printf("SON TOTES IGUALS\n");
            return tiradaPredeterminada(arrel->tauler);}

        for (int i=0; i < arrel->n_fills; i++){
            if (arrel->fills[i]->valor == punts){
                int columna = nfill_columna(arrel->tauler, i);
                //printf("Escollim columna %d amb valor %.2lf\n", columna, punts);
                return columna;
            }
        }


    }
    return -1;
}

int tiradaBot(Node *arrel){
    int columna = MiniMax(arrel, 0);
    printf("-Bot: Escullo la columna %i\n", columna+1);
    int fila = gravity_sim(arrel->tauler, columna);//funcionar�? o usar� un tauler ja modificat???
    arrel->tauler[fila][columna] = '2';

    // Comprovem si guanya!
    if (victoria(arrel->tauler, '2', fila, columna)){
        return 1;
    }
    else{return 0;}
}

void recorreArbreRec(Node *arrel, int nivell, int comptador){
    for (int i = 0; i < nivell; i++){
        printf("  "); // CADA NIVELL AFEGEIX 2 ESPAIS
    }
    printf("%i-(%.0lf)\n", ++comptador, arrel->valor);
    //prescindible
    /*if (nivell == PROF){
        printf("HOJA, nivel %i\n", nivell);
        return;
    }*/

    for(int i=0; i<arrel->n_fills; i++){
        //comptador
        recorreArbreRec(arrel->fills[i], nivell+1, comptador);
    }
}
//IMPRIMEIX VALORS -> VEURE MINIMAX
// EN CADA GRUP DELS PETITS AGAFEM EL M�NIM I DE TOTS AQUESTS AGAFEM EL M�XIM


int main() {
    #ifdef _WIN32
        system(""); // Activa ANSI a algunes versions de Windows
    #endif
	Node *arrel = malloc(sizeof(Node)); //el node inicial, situaci� actual
	// Inicialitzaci� del tauler a 0
    for(int i=0; i<N; i++){
        for(int j=0; j<M; j++){
            (arrel->tauler)[i][j]='0';
        }
    }
    //PROVES
    //(arrel->tauler)[N-3][1]='2';
    /*(arrel->tauler)[N-2][1]='2';
    (arrel->tauler)[N-1][1]='2';
    (arrel->tauler)[N-2][0]='1';
    (arrel->tauler)[N-1][0]='1';*/
    //FI PROVES

	//arrel->n_fills = calculaNumFills(arrel->tauler); //llegeix la 1a fila per veure quantes possibilitats hi ha
	//arrel->fills = malloc(arrel->n_fills * sizeof(Node*)); //reserva mem�ria pels fills


	//crearArbre(arrel, 0);
    //recorreArbreRec(arrel, 0);

    int empat = 1;
    int info=1;

    // TORNS DE TIRADES
    int pioneer = 0; //pioneer=0 -> comen�a el JUGADOR, pioneer=1 -> comen�a el BOT
    for (int i=pioneer; i<N*M+pioneer; i++){
        // Lo dels jugadors cal actualitzar-lo: bot t� una altra funci� per tirada.
        if (i%2 == 0){
            if (tirada(arrel->tauler, info)) { //POSSIBLES AJUSTOS
                printf("El jugador ha guanyat!\n");
                empat=0;
                break;
            }
        }
        else{
            if (i>2){
                arrel->n_fills = calculaNumFills(arrel->tauler); //llegeix la 1a fila per veure quantes possibilitats hi ha
                arrel->fills = malloc(arrel->n_fills * sizeof(Node*)); //reserva mem�ria pels fills
                crearArbre(arrel, 0);

                int guagua = tiradaBot(arrel);
                //recorreArbreRec(arrel, 0, 0);
                //printf("Valor del pare = %.0lf\n", arrel->valor);
                if (guagua){ //POSSIBLES AJUSTOS
                    printf("El bot ha guanyat!\n");
                    empat=0;
                    break;
                }
            }
            else {
                if (M==7){
                    if (arrel->tauler[N-1][1]=='1') arrel->tauler[N-1][2]='2';
                    else if (arrel->tauler[N-1][5]=='1') arrel->tauler[N-1][4]='2';
                    else tiradaPredPrimersTorns(arrel->tauler);
                }
                else{
                    tiradaPredPrimersTorns(arrel->tauler);
                }
            }
        }
    }

    if (empat)
        printf("Empat!\n");

    printf("\n-TAULER  FINAL-\n");
    printTauler(arrel->tauler);

    return 0;
}
