#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "joc.h"
#define PROF 2

typedef struct node {
	struct node * *fills;	//array de fills (pointers a node)
	int n_fills;
	char tauler[N][N];
	double valor;
} Node;

int nivell=0;

int calculaNumFills(char tauler[N][N]){
    int nfills=0;
    for(int i=0; i<N; i++){
        if(tauler[0][i]=='0')
            nfills++;
    }
    return nfills;
}//CAMBIAR!!!!1

int cosa = 1; //VALORS DEL PRINT TEMPORAL!!!

int nfill_columna(char tauler[N][N], int numDeFill){
    int columna = 0;
    for (int i=0; i<N; i++){
        if(detect(tauler, i, 0)){
            columna++;
        }
        if (columna == numDeFill){
            return columna;
        }
    }
}

int tiradaAuto(char tauler[N][N], int numDeFill){
    /*
    Qui tira dep�n del nivell:
    - nivell senar: bot
    - nivell parell: persona
    */
    char jugador;
    if (nivell%2)
        jugador='2';
    else
        jugador='1';

    // PRINT TAULA
    printf("    NIVELL %i\n", nivell);
    printTauler(tauler);

    //numDeFill diu quina posici� de les que hi ha lliures escull
    int columna = nfill_columna(tauler, numDeFill);
    int fila = gravity_sim(tauler, columna);

    tauler[fila][columna] = jugador;

    if (victoria(tauler, jugador, columna)){
        return 1;
    }
    else{return 0;}
}

// heur�stica avalua nom�s els nodes fulla. Nom�s determina vict�ria i/o derrota (inicialment)
int heuristica(char tauler[N][N], int numDeFill){
    int columna = nfill_columna(tauler, numDeFill);
    char jugador;
    if (nivell%2){
        //jugador='1';// POTSER CAL UNA REVISI�OOOOO
        if (victoria(tauler, '1', columna)){
            //##########################
            printf("Has guanyat!!!");
            return -100;
        }
    }
    else{
        printf("AQUI ESTAMOS\n");
        if (victoria(tauler, '2', columna)){
            printf("Has perdut.\n");
            return 100;
        }
    }
    return 0;
}

Node* creaNode(Node *pare, int numDeFill) {
    // La funci� crea el node fill.
    // Si �s possible reserva l'espai pels seus fills, sin� dona NULL i no t� m�s fills.

	Node *p=malloc(sizeof(Node)); //p �s node auxiliar
	//p->valor = cosa++; // ELIMINAR, ERA DE PROVA, PER VEURE QUE IMPRIMEIX A CADASCUN

	// Copiem el tauler
	memcpy(p->tauler, pare->tauler, sizeof(p->tauler));

    // Sobreescribm el tauler, coloquem fitxa
	//      tiradaAuto(p->tauler,numDeFill);


	if (nivell<PROF && !tiradaAuto(p->tauler, numDeFill)) { //Casos en els que pot tenir fills
		p->n_fills = calculaNumFills(p->tauler);
		p->fills = malloc(p->n_fills * sizeof(Node*));
	}
	else { //DECLAREM LES FULLES
		p->n_fills=0;
		p->fills=NULL;
        printf("    Truquem heurisitca, nivell %i.\n", nivell);
        p->valor = heuristica(p->tauler, numDeFill);
	}
	return p;
}

void creaNivell(Node *pare) {
    pare->valor=0;
	for(int i=0 ; i < pare->n_fills ; i++) {
		pare->fills[i] = creaNode(pare,i);
	}
}


// Es creen 2 nivells!! Potser RECURSIVAMENT podem arribar a N
void crearArbre(Node *arrel) {
    nivell=1;
	creaNivell(arrel);  //crea 1 nivell a partir de l'arrel (pare)

    //Creem un nivell (n nodes) per cadascun dels fills
	for(int i=0 ; i<arrel->n_fills ; i++) {
        nivell=2;
		creaNivell(arrel->fills[i]);
	}
}

/* NO RECURSIVAMENT
void recorreArbre(Node *arrel){
    int comptador=1;
    //PRINTEM L'ARBREEEEEE
    printf("%i-%f\n", comptador, arrel->valor);
    for(int i=0; i<arrel->n_fills; i++){
        comptador++;
        printf("  %i-%f\n", comptador, arrel->fills[i]->valor);//indent per veure q �s el primer nivell
        for (int j=0; j<arrel->fills[i]->n_fills; j++){
            comptador++;
            printf("    %i-%f\n", comptador, arrel->fills[i]->fills[j]->valor); //BAIXA UN ALTRE NIVELLLLLLL
        }
    }
}*/

// RECURSIVAMENT!!!! CALDR� FER-HO AMB TOT
int comptador=0;
void recorreArbreRec(Node *arrel, int nivell){
    for (int i =0; i<nivell; i++){
        printf("  "); // CADA NIVELL AFEGEIX 2 ESPAIS
    }
    printf("%i-%f\n", ++comptador, arrel->valor);
    for(int i=0; i<arrel->n_fills; i++){
        //comptador
        recorreArbreRec(arrel->fills[i], nivell+1);
    }
}
//IMPRIMEIX VALORS -> VEURE MINIMAX
// EN CADA GRUP DELS PETITS AGAFEM EL M�NIM I DE TOTS AQUESTS AGAFEM EL M�XIM


int main() {
    #ifdef _WIN32
        system(""); // Activa ANSI a algunes versions de Windows
    #endif
	Node *arrel = malloc(sizeof(Node)); //el node inicial, situaci� actual
	// Inicialitzaci� del tauler a 0
    for(int i=0; i<N; i++){
        for(int j=0; j<N; j++){
            (arrel->tauler)[i][j]='0';
        }
    }
    //PROVES
    (arrel->tauler)[1][0]='2';
    (arrel->tauler)[2][0]='2';
    (arrel->tauler)[3][0]='2';
    //FI PROVES

	arrel->n_fills=calculaNumFills(arrel->tauler); //llegeix la 1a fila per veure quantes possibilitats hi ha

	arrel->fills=malloc( arrel->n_fills * sizeof(Node*)); //reserva mem�ria pels fills

	int fila;

	crearArbre(arrel);
	//recorreArbre(arrel);
    recorreArbreRec(arrel, 0); //primer nivell 0

    int jugador; // SI �S 1 �S JUGADOR, 2 �S BOT
    int empat = 1;
    int info=1;

    // TORNS DE TIRADES

    /*EST� FATAL:
    ARREL->TAULER �S L'INICIAL, AQUEST CODI NO AVAN�A*/
    /*for (int i=0; i<N*N; i++){
        // Lo dels jugadors cal actualitzar-lo: bot t� una altra funci� per tirada.
        if (i%2 == 0){
            jugador = 1; //persona
            if (tirada(arrel->tauler, info)) { //POSSIBLES AJUSTOS
                printf("El jugador %i ha guanyat!\n", jugador);
                empat=0;
                break;
            }
        }
        else{
            jugador = 2; //bot
            if (tiradaAuto(arrel->tauler, info)) { //POSSIBLES AJUSTOS
                printf("El jugador %i ha guanyat!\n", jugador);
                empat=0;
                break;
            }
        }
    }

    if (empat)
        printf("Empat!\n");

    printf("\n-TAULER  FINAL-\n");
    printTauler(arrel->tauler);*/

    return 0;
}
