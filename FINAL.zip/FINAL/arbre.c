#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "joc.h"
#define PROF 2

typedef struct node {
	struct node * *fills;	//array de fills (pointers a node)
	int n_fills;
	char tauler[N][N];
	double valor;
} Node;

int nivell=0;

int calculaNumFills(char tauler[N][N]){
    int nfills=0;
    for(int i=0; i<N; i++){
        if(tauler[0][i]=='0')
            nfills++;
    }
    return nfills;
}//CAMBIAR!!!!1

int cosa = 1; //VALORS DEL PRINT TEMPORAL!!!

int tiradaBot(char tauler[N][N], int numDeFill){
    // PRINT TAULA
    printTauler(tauler);

    //numDeFill diu quina posici� de les que hi ha lliures escull
    int columna = 0, fila;
    for (int i=0; i<N; i++){
        if(detect(tauler, i, 0)){
            columna++;
        }
        if (columna == numDeFill){
            break;
        }
    }

    fila = gravity_sim(tauler, columna);
    tauler[fila][columna] = '2';
    //cridar a vict�ria des d'aqu�

    if (victoria(tauler, '2', fila, columna)){
        return 1;
    }
    else{return 0;}
}

Node* creaNode(Node *pare, int numDeFill) {
	Node *p=malloc(sizeof(Node)); //p �s node auxiliar
	p->valor = cosa++;

	// Copiem el tauler
	memcpy(p->tauler, pare->tauler, sizeof(p->tauler));

	tiradaBot(p->tauler,numDeFill); //falta &fila, &columna!!! MIRAR SI INTERFEREIX AMB L'ESTRUCTURA DE NODE

	if (nivell<PROF) {
		p->n_fills=calculaNumFills(p->tauler);//POTSER p
		p->fills=malloc( p->n_fills * sizeof(Node*));
	}
	else {
		p->n_fills=0;
		p->fills=NULL;
	}
	return p;
}

void creaNivell(Node *pare) {
	for(int i=0 ; i < pare->n_fills ; i++) {
		pare->fills[i] = creaNode(pare,i);
	}
}

void crearArbre(Node *arrel) {
    nivell=1;
	creaNivell(arrel);  //crea 1 nivell a partir d'aquest pare

	for(int i=0 ; i<arrel->n_fills ; i++) {
        nivell=2;
		creaNivell(arrel->fills[i]);
	}
}

/*
//NO RECURSIVAMENT
void recorreArbre(Node *arrel){
    int comptador=1;
    //PRINTEM L'ARBREEEEEE
    printf("%i-%f\n", comptador, arrel->valor);
    for(int i=0; i<arrel->n_fills; i++){
        comptador++;
        printf("  %i-%f\n", comptador, arrel->fills[i]->valor);//indent per veure q �s el primer nivell
        for (int j=0; j<arrel->fills[i]->n_fills; j++){
            comptador++;
            printf("    %i-%f\n", comptador, arrel->fills[i]->fills[j]->valor); //BAIXA UN ALTRE NIVELLLLLLL
        }
    }
}*/

// RECURSIVAMENT!!!! CALDR� FER-HO AMB TOT
int comptador=0;
void recorreArbreRec(Node *arrel, int nivell){
    for (int i =0; i<nivell; i++){
        printf("  "); // CADA NIVELL AFEGEIX 2 ESPAIS
    }
    printf("%i-%f\n", ++comptador, arrel->valor);
    for(int i=0; i<arrel->n_fills; i++){
        //comptador
        recorreArbreRec(arrel->fills[i], nivell+1);
    }
}
//IMPRIMEIX VALORS -> VEURE MINIMAX
// EN CADA GRUP DELS PETITS AGAFEM EL M�NIM I DE TOTS AQUESTS AGAFEM EL M�XIM

int main() {
    #ifdef _WIN32
        system(""); // Activa ANSI a algunes versions de Windows
    #endif
	Node *arrel = malloc(sizeof(Node)); //el node inicial, situaci� actual
	// Inicialitzaci� del tauler a 0
	    for(int i =0; i<N; i++)
            for(int j=0; j<N; j++)
                (arrel->tauler)[i][j]='0';

	arrel->n_fills=calculaNumFills(arrel->tauler); //llegeix la 1a fila per veure quantes possibilitats hi ha

	arrel->fills=malloc( arrel->n_fills * sizeof(Node*)); //reserva mem�ria pels fills

	int fila;

	crearArbre(arrel);
	//recorreArbre(arrel);
    recorreArbreRec(arrel, 0); //primer nivell 0

    int jugador; // SI �S 1 �S JUGADOR, 2 �S BOT
    int empat = 1;
    int info=1;

    // TORNS DE TIRADES

    /*EST� FATAL:
    ARREL->TAULER �S L'INICIAL, AQUEST CODI NO AVAN�A*/
    for (int i=0; i<N*N; i++){
        // Lo dels jugadors cal actualitzar-lo: bot t� una altra funci� per tirada.
        if (i%2 == 0){
            jugador = 1; //persona
            if (tirada(arrel->tauler, info)) { //POSSIBLES AJUSTOS
                printf("El jugador %i ha guanyat!\n", jugador);
                empat=0;
                break;
            }
        }
        else{
            jugador = 2; //bot
            if (tiradaBot(arrel->tauler, info)) { //POSSIBLES AJUSTOS
                printf("El jugador %i ha guanyat!\n", jugador);
                empat=0;
                break;
            }
        }
    }

    if (empat)
        printf("Empat!\n");

    printf("\n-TAULER  FINAL-\n");
    printTauler(arrel->tauler);

    return 0;
}
