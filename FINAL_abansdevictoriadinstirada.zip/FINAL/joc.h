#define N 8
#define INFO 1 // en cas que vulguem info pels jugadors

#define ANSI_COLOR_J1    "\x1b[34m"     //BLAU
#define ANSI_COLOR_J2     "\x1b[31m"    //VERMELL
#define ANSI_COLOR_RESET   "\x1b[0m"

void printTauler(char tauler[N][N]);
int detect(char tauler[N][N], int columna, int info);
int gravity_sim(char tauler[N][N], int columna);
void tirada(char tauler[N][N], int *fila, int *columna, int info);
int victoria(char tauler[N][N], char fitxa, int fila, int columna);
